package com.example.itype;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class VistaRegistro extends AppCompatActivity {

    private String usuarioprueba = "usuario";
    private String contraprueba = "1234";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vista_registro);
    }

    public boolean verifUsuarioReg()
    {
        boolean verif_user = true;      // el usuario ingresado no está en la base de datos
        EditText usuarioText = (EditText) findViewById(R.id.editText_vRegUsuario);
        String stringUsuario = usuarioText.getEditableText().toString();

        System.out.println("verif_user: " + stringUsuario + ". usuarioprueba: " + usuarioprueba);

        //

        //CORRECTO -> for(int i = 0; i < TAMAÑO_BASEUSUARIOS; i++) {
        for(int i = 0; i < 5; i++) {
            if (stringUsuario.contentEquals(usuarioprueba)) {
                verif_user = false;     // el usuario ingresado ya está en la base de datos. No valido
                mensajeRegistroFalloExistente();
                break;
            }
        }
        return verif_user;
    }

    public boolean verifContraReg()
    {
        boolean verif_contra = false;
        EditText contraText = (EditText) findViewById(R.id.editText_vRegContra);
        String stringContra = contraText.getEditableText().toString();

        System.out.println("Registro: verif_contra: " + stringContra + ". Registro: contraprueba: " + contraprueba);

        //CORRECTO -> if( CUMPLE CON REQUISITOS DE CONTRASEÑA)
        if(stringContra.contentEquals(contraprueba))
        {
            verif_contra = true;
        }

        return verif_contra;
    }

    public void verificacionRegistro(View view)
    {
        if(verifUsuarioReg()== true && verifContraReg() == true )
        {
           mensajeRegistroExito();
           Intent randomIntent = new Intent(this, MainActivity.class);
           startActivity(randomIntent);
        }

        mensajeRegistroFallo();
    }

    public void regresoInicio (View view) {

        // Create an Intent to start the second activity
        Intent randomIntent = new Intent(this, MainActivity.class);
        // Start the new activity.
        startActivity(randomIntent);
    }

    // Usar este método cuando se ha completado de registar nuevo usuario
    public void mensajeRegistroExito(){
        Toast myToast = Toast.makeText(this, "¡Usuario creado con éxito!. Ingrese nuevamente las credenciales",
                Toast.LENGTH_LONG);
        myToast.show();
    }

    // Usar este método cuando se verifica que el usuario ya existe
    public void mensajeRegistroFalloExistente(){
        Toast myToast = Toast.makeText(this, "El usuario ya existe",
                Toast.LENGTH_LONG);
        myToast.show();
    }

    // Usar este método cuando se verifica que el usuario / contraseña no cumplen con los requisitos
    public void mensajeRegistroFallo(){
        Toast myToast = Toast.makeText(this, "El nombre de usuario o contraseña no cumplen con los requisitos. Pruebe otra vez.",
                Toast.LENGTH_LONG);
        myToast.show();
    }
}
