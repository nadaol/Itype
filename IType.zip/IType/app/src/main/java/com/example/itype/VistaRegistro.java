package com.example.itype;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class VistaRegistro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vista_registro);
    }

    public void regresoInicio (View view) {

        // Create an Intent to start the second activity
        Intent randomIntent = new Intent(this, MainActivity.class);
        // Start the new activity.
        startActivity(randomIntent);
    }


    // Usar este método cuando se ha completado de registar nuevo usuario
    public void mensajeRegistroExito(View view){
        Toast myToast = Toast.makeText(this, "¡Usuario creado con éxito!",
                Toast.LENGTH_LONG);
        myToast.show();
    }

    // Usar este método cuando se verifica que el usuario ya existe
    public void mensajeRegistroFalloExistente(View view){
        Toast myToast = Toast.makeText(this, "El usuario ya existe",
                Toast.LENGTH_LONG);
        myToast.show();
    }

    // Usar este método cuando se verifica que el usuario / contraseña no cumplen con los requisitos
    public void mensajeRegistroFallo(View view){
        Toast myToast = Toast.makeText(this, "El nombre de usuario o contraseña no cumplen con los requisitos. Pruebe otra vez.",
                Toast.LENGTH_LONG);
        myToast.show();
    }
}
