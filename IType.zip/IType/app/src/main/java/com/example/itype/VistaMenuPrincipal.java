package com.example.itype;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class VistaMenuPrincipal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vista_menu_principal);
    }

    public void regresoInicio (View view) {

        Intent randomIntent = new Intent(this, MainActivity.class);
        startActivity(randomIntent);
    }

    public void irSeleccionNivel (View view) {

        // Create an Intent to start the second activity
        Intent randomIntent = new Intent(this, VistaSeleccionNivel.class);
        // Start the new activity.
        startActivity(randomIntent);
    }

    public void irEstadisticas (View view) {

        // Create an Intent to start the second activity
        Intent randomIntent = new Intent(this, VistaEstadisticas.class);
        // Start the new activity.
        startActivity(randomIntent);
    }
}
