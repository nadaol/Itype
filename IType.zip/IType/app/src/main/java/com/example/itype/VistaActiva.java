package com.example.itype;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class VistaActiva extends AppCompatActivity implements View.OnClickListener{

    private String dificultad_juego;
    private ArrayList<String> palabras;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vista_activa);

        Bundle b = getIntent().getExtras();
        String dificultad_juego = b.getString("dificultad");
        Button btnlogout = (Button) findViewById(R.id.button_vActivaSalir);
        btnlogout.setOnClickListener(this);

    }

    public void getListaPalabras(){
    }

    public void validarPalabra(){
    }

    public void actualizarPalabra(){
    }

    public void estadisticasFinales(){
    }

    public void puntaje(){
    }

    public void intentoSalida(View view){
        // Al hacer clic en boton de regresar, debe preguntar si desea salir o no.
    }
    public void irEstadisticas(View view){
        Intent i = new Intent(this, VistaEstadisticas.class);
        startActivity(i);
    }
    public void regresoMenu () {
        Intent i = new Intent(this, VistaMenuPrincipal.class);
        startActivity(i);
    }


    @Override
    public void onClick(View view) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("¿Desea regresar a menú principal?");
        builder.setMessage("Se perderá el progreso de la partida");
        builder.setPositiveButton("Si. Regresar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i){
                //finish();
                regresoMenu();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i){
               dialogInterface.dismiss();
        }
        });
    AlertDialog dialog = builder.create();
        dialog.show();
    }
}

   /* public void onBackPressed(View view) {
        new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("¿Desea volver al menú principal?")
                .setMessage("Se perderá el progreso de la partida")
                .setPositiveButton("Si", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        regresoMenu();
                    }

                })
                .setNegativeButton("No", null)
                .show();
    }*/



