package com.example.itype;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class VistaActiva extends AppCompatActivity {

    private String dificultad_juego;
    private ArrayList<String> palabras;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vista_activa);

        Bundle b = getIntent().getExtras();
        String dificultad_juego = b.getString("dificultad");
    }

    public void getListaPalabras(){
    }

    public void validarPalabra(){
    }

    public void actualizarPalabra(){
    }

    public void estadisticasFinales(){
    }

    public void puntaje(){
    }

    public void intentoSalida(View view){
        // Al hacer clic en boton de regresar, debe preguntar si desea salir o no.
    }
    public void irEstadisticas(View view){
        Intent i = new Intent(this, VistaEstadisticas.class);
        startActivity(i);
    }
    public void regresoMenu (View view) {
        Intent i = new Intent(this, VistaSeleccionNivel.class);
        startActivity(i);
    }
}
