package com.example.itype;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    private String usuarioprueba = "usuario";
    private String contraprueba = "1234";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public boolean verificarUsuario()
    {
        boolean verif_user = false;
        EditText usuarioText = (EditText) findViewById(R.id.editText_vInicioUsuario);
        String stringUsuario = usuarioText.getEditableText().toString();

        System.out.println("verif_user: " + stringUsuario + ". usuarioprueba: " + usuarioprueba);

        if(stringUsuario.contentEquals(usuarioprueba))
        {
            verif_user = true;
        }

        return verif_user;
    }

    public boolean verificarContra()
    {
        boolean verif_contra = false;
        EditText contraText = (EditText) findViewById(R.id.editText_vInicioContra);
        String stringContra = contraText.getEditableText().toString();

        System.out.println("Inicio: verif_contra: " + stringContra + ". Inicio: contraprueba: " + contraprueba);

        if(stringContra.contentEquals(contraprueba))
        {
            verif_contra = true;
        }

        return verif_contra;
    }

    public void verificacionIngreso(View view)
    {
        if(verificarContra() == true && verificarUsuario() == true )
        {
            mensajeCorrecto();
            //Toast myToast = Toast.makeText(this, "Bienvenido. ¡Disfrute del desafío!",
            //        Toast.LENGTH_LONG);
            //myToast.show();
            irMenuPrincipal();
            return;
        }

        mensajeNoUsuario();
        return;
    }

    public void irRegistro (View view) {

        // Create an Intent to start the second activity
        Intent randomIntent = new Intent(this, VistaRegistro.class);
        startActivity(randomIntent);

    }

    public void irMenuPrincipal () {

        // Create an Intent to start the second activity
        Intent randomIntent = new Intent(this, VistaMenuPrincipal.class);
        startActivity(randomIntent);
    }

    // Usar este método cuando la verificación arroja un usuario o contraseña incorrecta
    public void mensajeContraIncorrecta(View view){
        Toast myToast = Toast.makeText(this, "La contraseña es incorrecta. Intente otra vez",
                Toast.LENGTH_LONG);
        myToast.show();
    }

    // Usar este método cuando no existe usuario ingresado en la base de datos de usuarios.
    public void mensajeNoUsuario(){
        Toast myToast = Toast.makeText(this, "Usuario no existente. ¡Regístre el usuario ingresado!",
                Toast.LENGTH_LONG);
        myToast.show();
    }

    // Usar este método cuando la verificación es correcta
    public void mensajeCorrecto(){
        Toast myToast = Toast.makeText(this, "Bienvenido. ¡Disfrute del desafío!",
                Toast.LENGTH_LONG);
        myToast.show();
    }

}
